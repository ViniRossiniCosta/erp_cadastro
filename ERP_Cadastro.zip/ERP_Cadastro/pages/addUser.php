<?php

require_once '../settings/connection.php';
require_once 'header.php';

if ($id == '') {
  header('Location: login.php');
  exit;
}

?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<link rel="stylesheet" href="assests/css/register.css">

<body>
  <form action="" method="">
    <h2 style="text-align: center; margin: 3% auto">Adicionando Usuario</h2>
    <form action="./settings/registered.php" method="POST" onsubmit="return validateForm()">
      <div class="row jumbotron box8 ">
        <div class="col-sm-12 mx-t3 mb-4">
          <h2 class="text-center text-warning">Adicionar Cadastros</h2>
        </div>
        <div class="col-sm-6 form-group">
          <label for="name-f">Nome</label>
          <input type="text" class="form-control" name="addUsername" id="username" placeholder="Digite seu nome" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" name="addEmail" id="email" placeholder="Digite seu email" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="address-1">CPF</label>
          <input type="text" class="form-control" name="addCpf" id="cpf" placeholder="Digite seu CPF" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="cep">Cep</label>
          <input type="text" class="form-control" maxlength="9" name="addCep" id="id_cep" placeholder="00000-000" required>
        </div>
        <div class="col-sm-4 form-group">
          <label for="State">Cidade</label>
          <input type="address" class="form-control" name="add_city" id="id_city" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Estado</label>
          <input type="zip" class="form-control" name="add_states" id="id_state" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Bairro</label>
          <input type="zip" class="form-control" name="add_neighborhood" id="id_neighborhood" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Rua</label>
          <input type="zip" class="form-control" name="add_street" id="id_street" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Número</label>
          <input type="zip" class="form-control" name="add_complement" id="complement" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="Date">Data de Nascimento</label>
          <input type="Date" name="dob" class="form-control" onblur="calAge()" name="add_birthdate" id="id_birthdate" placeholder="" required>
        </div>
        <div class="col-sm-12 form-group mb-0 d-flex justify-content-center align-items-center pt-4 pb-4"></div>
        <button class="btn text-light float-right w-100 bg-success" style="height: 50px; font-size: 1.4em;">Adicionar Usuario</button>
      </div>
      </div>
    </form>
</body>