<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cadastro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <link rel="stylesheet" href="assests/css/register.css">
</head>

<body>
  <?php require_once('header.php') ?>
  <div class="container mt-3">
    <form action="./settings/registered.php" method="POST" onsubmit="return validateForm()">
      <div class="row jumbotron box8 ">
        <div class="col-sm-12 mx-t3 mb-4">
          <h2 class="text-center text-warning">Cadastro</h2>
        </div>
        <div class="col-sm-6 form-group">
          <label for="name-f">Nome</label>
          <input type="text" class="form-control" name="username" id="username" placeholder="Digite seu nome" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" name="email" id="email" placeholder="Digite seu email" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="address-1">CPF</label>
          <input type="text" class="form-control" name="cpf" id="cpf" placeholder="Digite seu CPF" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="cep">Cep</label>
          <input type="text" class="form-control" maxlength="9" name="cep" id="id_cep" placeholder="00000-000" required>
        </div>
        <div class="col-sm-4 form-group">
          <label for="State">Cidade</label>
          <input type="address" class="form-control" name="city" id="id_city" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Estado</label>
          <input type="zip" class="form-control" name="states" id="id_state" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Bairro</label>
          <input type="zip" class="form-control" name="neighborhood" id="id_neighborhood" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Rua</label>
          <input type="zip" class="form-control" name="street" id="id_street" disabled required>
        </div>
        <div class="col-sm-2 form-group">
          <label for="zip">Número</label>
          <input type="zip" class="form-control" name="complement" id="complement" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="Date">Data de Nascimento</label>
          <input type="Date" name="dob" class="form-control" onblur="calAge()" name="birthdate" id="id_birthdate" placeholder="" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="tel">Telefone</label>
          <input type="tel" name="phone" class="form-control" id="cellphone" placeholder="(00)0000-0000" required>
        </div>
        <div class="col-sm-6 form-group">
          <label for="pass">Senha</label>
          <input type="Password" name="pass" class="form-control" id="id_pass" placeholder="Digite sua senha" required onchange="validatePasswordLength(event)">
        </div>
        <div class="col-sm-6 form-group">
          <label for="pass2">Confirma Senha</label>
          <input type="Password" name="cnf-pass" class="form-control" id="id_pass2" placeholder="Re-insira a senha" required onchange="validatePasswords()">
        </div>
        <div class="col-sm-12 form-group mb-0 d-flex justify-content-center align-items-center pt-4 pb-4">
          <button class="btn text-light float-right w-100 bg-success" style="height: 50px; font-size: 1.4em;">Cadastrar</button>
        </div>
      </div>
    </form>
  </div>
  <script src="/assests/js/register.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/imask"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.0/dist/sweetalert2.min.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var cpfMask = IMask(document.getElementById('cpf'), {
        mask: '000.000.000-00',
        lazy: false
      });

      const cepInput = document.getElementById('id_cep');
      cepInput.addEventListener('input', () => {
        let value = cepInput.value;
        value = value.replace(/\D/g, '');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
        cepInput.value = value;
      });

      const inputCep = document.getElementById('id_cep');
      inputCep.addEventListener('input', () => {
        const cep = inputCep.value.replace(/\D/g, '');
        if (cep.length === 8) {
          const url = `https://viacep.com.br/ws/${cep}/json/`;
          fetch(url)
            .then(response => response.json())
            .then(data => {
              document.getElementById('id_street').value = data.logradouro;
              document.getElementById('id_neighborhood').value = data.bairro;
              document.getElementById('id_city').value = data.localidade;
              document.getElementById('id_state').value = data.uf;
            })
            .catch(error => {
              console.log('Erro');
              console.log(error);
            });
        }
      });

      var cellphone = IMask(document.getElementById('cellphone'), {
        mask: '(00) 00000-0000',
        lazy: false
      });
    });

    function validateForm() {
      if (!validateCPF(document.getElementById('cpf').value)) {
        Swal.fire({
          icon: 'error',
          title: 'Erro',
          text: 'CPF inválido'
        });
        return false;
      }

      if (!validateCEP(document.getElementById('id_cep').value)) {
        Swal.fire({
          icon: 'error',
          title: 'Erro',
          text: 'CEP inválido'
        });
        return false;
      }

      return true;
    }

    function calAge() {
      // Obtenha a data de nascimento do elemento de entrada
      var dobInput = document.getElementById("id_birthdate");
      var dob = new Date(dobInput.value);

      // Obtenha a data atual
      var currentDate = new Date();

      // Calcule a diferença em milissegundos entre as duas datas
      var timeDiff = currentDate - dob;

      // Converta a diferença de milissegundos para anos
      var age = Math.floor(timeDiff / (1000 * 60 * 60 * 24 * 365.25));

      // Exiba a idade no console (você pode querer usar isso de forma diferente, como exibir em um campo de texto)
      console.log("Idade:", age);

      // Se desejar, você pode armazenar a idade em um campo de texto
      document.getElementById("idade").value = age;
    }

    function validatePasswordLength(event) {
      let password = event.target.value;
      if (password.length < 6) {
        Swal.fire({
          icon: "warning",
          title: "Aviso",
          text: "A senha deve ter pelo menos 6 caracteres.",
        });
        return false;
      }
      return true;
    }

    function validatePasswords() {
      let fstPassword = document.getElementById("id_pass").value;
      let sndPassword = document.getElementById("id_pass2").value;

      if (fstPassword !== sndPassword) {
        Swal.fire({
          icon: "error",
          title: "Erro",
          text: "As senhas são diferentes",
        });
        return false;
      }

      return true;
    }
  </script>
</body>

</html>