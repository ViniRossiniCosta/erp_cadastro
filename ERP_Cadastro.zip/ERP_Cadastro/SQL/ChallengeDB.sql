create database ChallengeDB;

use ChallengeDB;

CREATE TABLE users (
    id_user INT PRIMARY KEY AUTO_INCREMENT,
    permission TINYINT DEFAULT NULL,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    pass VARCHAR(255) NOT NULL,
    cellphone VARCHAR(15) DEFAULT NULL,
    cpf VARCHAR(15) NOT NULL,
    cep VARCHAR(10) DEFAULT NULL,
    states VARCHAR(2) NOT NULL,
    city VARCHAR(100) NOT NULL,
    neighborhood VARCHAR(100) NOT NULL,
    street VARCHAR(100) DEFAULT NULL,
    complement VARCHAR(255) DEFAULT NULL,
    birthdate TIMESTAMP DEFAULT NULL,
    createUser TIMESTAMP DEFAULT NULL,
    updateUser TIMESTAMP DEFAULT NULL
);
