const urlParams = new URLSearchParams(window.location.search);
const userState = urlParams.get("userState");

if (userState == 1) {
  Swal.fire({
    icon: "success",
    title: "editado com sucesso",
  });
}

if (userState == 6) {
  Swal.fire({
    icon: "erro",
    title: "Putz",
    text: "Ocorreu um erro ao editar o perfil",
  });
}

function passwordValidate() {
  $.ajax({
    url: "../settings/passwordVerify.php",
    method: "POST",
    data: {
      pass: pass,
      id: id,
    },
    success: function (obj) {
      if (obj == "1") {
        Swal.fire({
          icon: "success",
          title: "Sua senha ja pode ser alterada",
          text: "Agora você pode alterar a senha",
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Putz",
          text: "Senha Incorreta",
        });
      }
    },
  });
}




