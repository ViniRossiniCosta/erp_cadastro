const urlParams = new URLSearchParams(window.location.search);
const userState = urlParams.get("userState");

if (userState == 1) {
  Swal.fire({
    icon: "success",
    title: "Usuario adicionado com sucesso!",
  });
}

if (userState == 5) {
  Swal.fire({
    icon: "error",
    title: "Putz",
    text: "Houve um erro ao adicionar o cadastro",
  });
}
