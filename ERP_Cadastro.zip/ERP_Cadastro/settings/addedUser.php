<?php

require_once("connection.php");

$username = '';
$email = '';
$cpf = '';
$cep = '';
$birthdate = '';
$city = '';
$states = '';
$neighborhood = '';
$street = '';
$complement = '';

if ($_POST['addUsername']) {
    $username = $_POST['addUsername'];
}

if ($_POST['addEmail']) {
    $username = $_POST['addEmail'];
}

if ($_POST['addCpf']) {
    $username = $_POST['addCpf'];
}

if ($_POST['addCep']) {
    $username = $_POST['addCep'];
}

if ($_POST['add_city']) {
    $username = $_POST['add_city'];
}

if ($_POST['add_states']) {
    $username = $_POST['add_states'];
}

if ($_POST['add_neighborhood']) {
    $username = $_POST['add_neighborhood'];
}

if ($_POST['add_street']) {
    $username = $_POST[''];
}

if ($_POST['add_complement']) {
    $username = $_POST['add_complement'];
}

if ($_POST['add_birthdate']) {
    $username = $_POST['add_birthdate'];
}


$sql = "INSERT INTO users (username, email, cpf, cep, birthdate, city, states,
neighborhood, street, complement) VALUES ('" . $username . "', '" . $email . "', '" . $cpf . "', '" . $cep . "', '" . $birthdate . "', '" . $city . "', '" . $states . "', '" . $neighborhood . "', '" . $street . "', '" . $complement . "')";

if (mysqli_query($conn, $sql)) {
    header("Location: ../pages/addUser.php?userState=1");
} else {
    header("Location: ../pages/addUser.php?userState=5");
}
