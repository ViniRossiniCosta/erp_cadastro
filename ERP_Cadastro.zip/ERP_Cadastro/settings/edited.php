<?php

require_once 'connection.php';

$username = '';
$email = '';
$cpf = '';
$cep = '';
$birthdate = '';
$city = '';
$states = '';
$neighborhood = '';
$street = '';
$pass = '';
$cellphone = '';
$complement = '';
$id_user = '';

if ($_POST['pass'] != '') {
    $pass = password_hash($_POST['pass'], PASSWORD_BCRYPT);
}

if ($_POST['username'] != '') {
    $username = $_POST['username'];
}
if ($_POST['email'] != '') {
    $email = $_POST['email'];
}
if ($_POST['cellphone'] != '') {
    $cellphone = $_POST['cellphone'];
}
if ($_POST['states'] != '') {
    $states = $_POST['states'];
}
if ($_POST['city'] != '') {
    $city = $_POST['city'];
}
if ($_POST['cep'] != '') {
    $cep = $_POST['cep'];
}
if ($_POST['neighborhood'] != '') {
    $neighborhood = $_POST['neighborhood'];
}
if ($_POST['street'] != '') {
    $street = $_POST['street'];
}
if ($_POST['complement'] != '') {
    $complement = $_POST['complement'];
}
if ($_POST['id_user'] != '') {
    $id_user = $_POST['id_user'];
}

if ($pass != '') {
    $sqlPassword = "UPDATE users SET pass = '" . $pass . "' WHERE id_user = '" . $id_user . "'";
}

$sql = "UPDATE users SET 
username = '" . $username . "',
email = '" . $email . "',
cellphone = '" . $cellphone . "',
states = '" . $states . "',
city = '" . $city . "',
cep = '" . $cep . "',
cpf = '" . $cpf . "',
neighborhood = '" . $neighborhood . "',
street = '" . $street . "',
complement = '" . $complement . "',
updateUser = NOW()
WHERE id_user = '" . $id_user . "'";

if (mysqli_query($conn, $sql)) {
    header("Location: ../pages/edit.php?userState=1");
} else {
    header("Location: ../pages/edit.php?userState=6");
}

mysqli_close($conn);
