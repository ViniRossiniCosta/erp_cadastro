<?php

require_once("connection.php");

$pass = '';
$id = '';

if ($_POST['pass'] != "") {
    $pass = $_POST['pass'];
}
if ($_POST['id'] != "") {
    $id = $_POST['id'];
}

$sql = "SELECT pass FROM users WHERE id_user ='" . $id . "'";
$result = mysqli_query($conn, $sql);

while ($verify = mysqli_fetch_assoc($result)) { 
    if(password_verify($pass, $verify["password"])) {
        echo '1';
    }else {
        echo '2';
    }
}

