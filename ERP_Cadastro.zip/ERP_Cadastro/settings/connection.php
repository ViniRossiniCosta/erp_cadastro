<?php

// Definindo as credenciais do banco
$servername = "localhost";
$username = "root";
$password = ""; // ou root
$database = "ChallengeDB";

$conn = new mysqli($servername, $username, $password, $database);

if(!$conn) {
    // Caso a conexao venha a falhar
    echo('erro de conexão com o Banco' .mysqli_connect_error());
}


