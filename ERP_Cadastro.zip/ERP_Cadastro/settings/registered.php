<?php

require_once 'connection.php';

$username = '';
$email = '';
$cpf = '';
$cep = '';
$birthdate = '';
$city = '';
$states = '';
$neighborhood = '';
$street = '';
$pass = '';
$cellphone = '';
$complement = '';

if ($_POST['username'] != '') {
    $username = $_POST['username'];
}

if ($_POST['email'] != '') {
    $email = $_POST['email'];
}

if ($_POST['cpf'] != '') {
    $cpfF = str_replace('.', "", $_POST['cpf']);
    $cpf = str_replace('-', "", $cpfF);
}

if ($_POST['id_cep'] != '') {
    $cep = $_POST['id_cep'];
}

if ($_POST['birthdate'] != '') {
    $birthdate = $_POST['birthdate'];
}

if ($_POST['state'] != '') {
    $state = $_POST['state'];
}

if ($_POST['city'] != '') {
    $city = $_POST['city'];
}

if ($_POST['cellphone'] != '') {
    $city = $_POST['cellphone'];
}

if ($_POST['neighborhood'] != '') {
    $neighborhood = $_POST['neighborhood'];
}

if ($_POST['street'] != '') {
    $street = $_POST['street'];
}

if ($_POST['complement'] != '') {
    $complement = $_POST['complement'];
}

if ($_POST['pass']) {
    $pass = password_hash($_POST['pass'], PASSWORD_BCRYPT);
}

$sql_verify = "SELECT email FROM users WHERE email = '" . $email . "'";

$result = mysqli_query($conn, $sql_verify);

if (mysqli_num_rows($result) == 0) {
    $query = "INSERT INTO users (username, email, pass, cpf, cep, birthdate, city, states, city, neighborhood, street, createUser) VALUES ('$username', '$email', '$cpf', '$cep', '$cellphone', 0, 0, '$state', '$city', '$neighborhood', '$street', '$complement', '$pass', NOW()";


    // Colocar os valores certos daqui a pouco
    if($result = mysqli_query($conn, $query)) { 
        header('Location: ../pages/index.php?userState=2');
        exit;
    }else {
        header('Location: ../pages/register.php?userState=3');
    }
} else {
    header('Location: ../pages/register.php?userState=4');
}
