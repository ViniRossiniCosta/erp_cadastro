<?php

session_start();
require_once 'connection.php';

$user = '';
$pass = '';

if ($_POST['email'] != '') {
    $user = $_POST['email'];
}

if ($_POST['pass'] != '') {
    $user = $_POST['pass'];
}

$sql = "SELECT id_user, email, username, pass, permission";

$result = mysqli_query($conn, $sql);

$orw = mysqli_num_rows($result);

if ($orw > 0) {
    while ($dados = mysqli_fetch_assoc($result)) {
        if (password_verify($pass, $dados['pass'])) {
            $_SESSION[''] = '1';
            $_SESSION['usr'] = $dados['id_user'];
            echo '3';
            exit;
        } else {
            echo '1';
        }
    }
} else {
    echo '2';
}
