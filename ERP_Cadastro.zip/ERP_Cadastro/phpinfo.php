<?php 
phpinfo()
?>