<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

  <title>Gerenciamento de cadastro</title>
</head>

<body>
  <header class="header-main">
    <nav class="navbar navbar-expand-lg bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand text-warning" href="\ERP_Cadastro\index.php">ERP</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <?php if ($id == '') { ?>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link text-warning" href="/ERP_Cadastro/pages/register.php">Cadastro</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="/ERP_Cadastro/pages/login.php">Login</a>
            </li>
          </ul>
        </div>
      <?php } else { ?>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link text-warning" href="/ERP_Cadastro/pages/addUser.php">Cadastro</a>
            </li>
        </div>
      <?php } ?>
    </nav>
  </header>
  <h1 class="container d-flex justify-content-center pt-3 pb-3">Gerenciamento Cadastros</h1>
  <?php
  $sql = "SELECT * FROM users where id_user = '" . $id . "'";
  $result = mysqli_query($conn, $sql);
  $num_users = mysqli_num_rows($result);

  if ($num_users == 0) {
    while ($user = mysqli_fetch_assoc($result)) {
  ?>
      <div class="d-flex align-items-center">
        <table class="table table-striped table-hover">
          <thead class="table-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">First</th>
              <th scope="col">Last</th>
              <th scope="col">Handle</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td colspan="2">Larry the Bird</td>
              <td>@twitter</td>
            </tr>
          </tbody>
      <?php
    }
  } else {
    echo '<a class="btn btn-success" href="/ERP_Cadastro/pages/addUser.php">Cadastrar Usuarios</a>';
  }
      ?>
        </table>
      </div>

      <!-- DataTables JavaScript -->
      <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

      <script>
        $(document).ready(function() {
          // Inicializar a DataTable
          $('.table').DataTable();
        });
      </script>
</body>

</html>